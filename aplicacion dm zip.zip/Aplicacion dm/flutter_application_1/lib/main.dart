import 'package:flutter/material.dart';

void main() {
  runApp(MiApp());
}

// ignore: use_key_in_widget_constructors
class MiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Mi Primera Aplicación'),
        ),
        body: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: <Widget>[
              Text(
                'Hola Mundo',
                style: TextStyle(fontSize: 24),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Text('Widget 1'),
                  Text('Widget 2'),
                  Text('Widget 3'),
                ],
              ),
              Stack(
                children: <Widget>[
                  Container(
                    width: 100,
                    height: 100,
                    color: Colors.red,
                  ),
                  Container(
                    width: 70,
                    height: 70,
                    color: Colors.green,
                  ),
                  Container(
                    width: 40,
                    height: 40,
                    color: Colors.blue,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


